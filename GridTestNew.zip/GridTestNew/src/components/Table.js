import React from "react";
import classnames from "classnames";

// Table
const Table = ({ children, className }) => {
  return <div className={classnames("table", className)}>{children}</div>;
};

export default Table;

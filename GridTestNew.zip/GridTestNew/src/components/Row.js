import React from "react";
import classnames from "classnames";
// Table
const Row = ({ children, className, wrapper = false }) => {
  return (
    <div className={classnames("row", className, { wrapper })}>{children}</div>
  );
};

export default Row;

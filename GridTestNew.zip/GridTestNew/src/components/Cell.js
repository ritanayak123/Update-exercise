import React from "react";
import classnames from "classnames";

const Cell = (props) => {
  const { children, className, grow = false } = props;
  return (
    <div className={classnames("cell", className, { grow })}>{children}</div>
  );
};

export default Cell;
